# group_A5_4
Internet Banking Application
description:
The main objective of the Online Banking System is to manage the details of accounts, Internet banking, transaction, balance, statement.It manages all the information about Accounts, Customer, Statement, Accounts. Internet banking, also known as online banking, e-banking or virtual banking, is an electronic payment system that enables customers of a bank or other financial institution to conduct a range of financial transactions.
Hardware requirements:
 Server Side:
Operating System : Windows 9x/xp ,Windows ME
 Processor       :Pentium 3.0 GHz or higher.
 RAM             : 256 Mb or more.
 Hard Drive      : 10 GB or more.
 Client side:
Operating System : Windows 9x or above, MAC or UNIX.             
 Processor       : Pentium III or 2.0 GHz or higher.                             
 RAM             : 256 Mb or more.
Software requirements:
 Web server      :HTML, MS Office, Windows XP/9x/ME.
 Client side     :HTML, Web Browser, Flash Player, MS Office, Windows XP/9x/ME.
 Doneby:
 SWARNA A
 SWETHA.G
 SRIMATHY.R





